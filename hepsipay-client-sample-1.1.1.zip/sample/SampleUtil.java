/*******************************************************************************
 * Copyright (C) 2017 Hepsipay and Contributers
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 ******************************************************************************/
package com.hepsipay.sample;

import com.hepsipay.client.settings.HepsiPaySetting;

/**
 * 
 * @author Ahmet Faruk Bişkinler,
 * @Support PixelTürk Web Studio, "destek@pixelturk.net"
 *
 */
public class SampleUtil {
	
	public static HepsiPaySetting generateSampleHepsiPaySetting() {
		HepsiPaySetting hepsiPaySettings = new HepsiPaySetting();
		hepsiPaySettings.setApiKey("ApiKey"); // Hepsipay tarafından size verilmiş olan API anahtarını giriniz
		hepsiPaySettings.setSecretKey("SecretKey"); // Hepsipay tarafından size verilmiş olan SecretKey bilgisini giriniz
		hepsiPaySettings.setTestMode(true); // Eğer canlı modda değil iseniz (test aşamasında iseniz) TRUE olarak işaretleyin. Canlı ortama geçtiğinizde FALSE işaretleyin yada bu satırı silin
		return hepsiPaySettings;
	}
	
}
