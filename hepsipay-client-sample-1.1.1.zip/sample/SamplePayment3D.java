/*******************************************************************************
 * Copyright (C) 2017 Hepsipay and Contributers
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 ******************************************************************************/
package com.hepsipay.sample;

import java.util.ArrayList;
import java.util.List;

import com.hepsipay.client.model.Basketitem;
import com.hepsipay.client.model.Card;
import com.hepsipay.client.model.Customer;
import com.hepsipay.client.model.Extra;
import com.hepsipay.client.model.InvoiceAddress;
import com.hepsipay.client.model.ShippingAddress;
import com.hepsipay.client.model.request.payment.Payment3D;
import com.hepsipay.client.service.PaymentService;
import com.hepsipay.client.settings.HepsiPaySetting;
import com.hepsipay.client.type.BasketItemType;
import com.hepsipay.client.type.Currency;
import com.hepsipay.client.util.HepsiPayUtil;

/**
 * 
 * @author Ahmet Faruk Bişkinler,
 * @Support PixelTürk Web Studio, "destek@pixelturk.net"
 *
 */
public class SamplePayment3D {
	
	public static void main(String[] args) {
		Payment3D payment3DRequest = new Payment3D();
		/**
		 * Create Payment3D Request
		 * Ödeme İsteği Oluştur
		 */
		//		payment3DRequest.setTransactiontime();    // Ödeme İşlem Zamanı, Varsayılan zaman ise şuan.
		//		payment3DRequest.setTransactionId("tx_" .  rand(100000, 999999));    // Ödemeye Ait Tekil Kodu (Maksimum 40 karakterdir)
		payment3DRequest.setTransactionId(HepsiPayUtil.generateRandomTranstionId()); // Ödemeye Ait Tekil Kodu (Maksimum 40 karakterdir)
		payment3DRequest.setDescription("E-Ticaret Ödemesi"); // Açıklama alanıdır (Maksimum 40 karakterdir)
		payment3DRequest.setAmount("120,99"); // Toplam Ödeme Tutarı
		payment3DRequest.setCurrency(Currency.TL.getCode()); // Toplam Ödeme Tutar Birimi
		payment3DRequest.setInstallment(9); // Ödeme Taksit Sayısı (1'den 12'ye kadar taksit değeridir)
		
		payment3DRequest.setSuccessUrl("http://example.com/payment_response.jsp?status=success"); // 3d secure işlemler için zorunlu bir alandır.İşlemin başarılı olması durumunda üye işyerine tarafından geliştirilmiş sayfanın URL'si yazılmalıdır.
		   payment3DRequest.setFailUrl("http://example.com/payment_response.jsp?status=fail"); // 3d secure işlemler için zorunlu bir alandır.İşlemin başarılı olması durumunda üye işyerine tarafından geliştirilmiş sayfanın URL'si yazılmalıdır.
		
		/**
		 * Credit Card Info
		 * Kredi Kartı Bilgileri
		 */
		Card card = new Card();
		card.setCardHolderName("John Doe"); // Kart İsim Soyisim (Maksimum 40 karakterdir. Sadece alfabetik karakterler ve boşluk kabul eder)
		card.setCardNumber("4531444531442283"); // Kart Numarası (15 veya 16 haneli nümerik değerdir)
		card.setExpireMonth("12"); // Kart Son Kullanım Tarihi (2 haneli nümerik değerdir.)
		card.setExpireYear("18"); // Kart Son Kullanım Tarihi (2 haneli nümerik değerdir.)
		card.setSecuritycode("001"); // Kart CVV (3 veya 4 haneli nümerik değerdir.)
		payment3DRequest.setCard(card);
		
		/**
		 * Customer Info
		 * Müşteri Bilgileri
		 */
		Customer customer = new Customer();
		customer.setName("Ali"); // Müşteri İsim (Maksimum 20 karakterdir. Sadece alfabetik karakterler ve boşluk kabul eder.)
		customer.setSurname("Veli"); // Müşteri Soyisim (Maksimum 20 karakterdir. Sadece alfabetik karakterler ve boşluk kabul eder.)
		customer.setEmail("ali.veli@alivelimarket.com.tr"); // Müşteri Mail (Eposta adresidir.)
		customer.setIpaddress("72.125.165.16"); // Müşteri IP Adresi (IP adresidir.)
		customer.setPhonenumber("+905350000000"); // Müşteri Telefon Numarası (Maksimum 13 karakterdir. Sadece nümerik ve + değerlerini alabilir.)
		customer.setCode("7cefdf61-38cd-4b35-b5f0-4c98c5805d41"); // Müşteri Kodu (Maksimum 36 karakterdir.)
		customer.setTckn("12345678910"); // Müşteri Kimik Numarısı (TC Kimlik numarasıdır.)
		customer.setVatNumber("12345678910"); // Müşteri Vergi Numarası (Şirketlere ve firmalara tekil vergi numarası)
		customer.setMemberSince("20151124"); // Müşteri Üyelik tarihi (Müşteri üyelik tarihi formatı YYYYMMDD’dır.)
		customer.setBirthdate("19781123"); // Müşteri Doğum tarihi (Müşteri üyelik tarihi formatı YYYYMMDD’dır.)
		payment3DRequest.setCustomer(customer);
		
		/**
		 * Shipping Address
		 * Teslimat/Nakliye Adresi
		 */
		ShippingAddress shippingAddress = new ShippingAddress();
		shippingAddress.setName("Ali Veli"); // Sipariş Teslimatının yapılacağı kişi adı ve soyadı (Maksimum 40 karakterdir. Sadece alfabetik karakterler ve boşluk kabul eder.)
		shippingAddress.setAddress("Kuştepe Mahallesi Mecidiyeköy Yolu Cad. No:12 Trump Towers Kule:2 Kat:11 Mecidiyeköy"); // Siparişin teslim edileceği adres (Maksimum 500 karakterdir. Sadece alfanümerik karakterler, &.,/: ve boşluk karakterini kabul eder.)
		shippingAddress.setCountry("Türkiye"); // Sipariş teslimatının yapılacağı ülke (Maksimum 20 karakterdir. Sadece alfabetik olabilir.)
		shippingAddress.setCountrycode("TUR"); // Sipariş teslimatının yapılacağı ülke (2 veya 3 haneli ISO ülke kodudur.Sadece alfabetik olabilir.)
		shippingAddress.setCity("Istanbul"); // Sipariş teslimatının yapılacağı şehir (Maksimum 20 karakterdir.Sadece alfabetik olabilir.)
		shippingAddress.setCitycode("34"); // Sipariş teslimatının yapılacağı şehir (Şehire ait ulusal veya uluslararası kod alanıdır. Türkiye için plaka kodu kullanılabilir.)
		shippingAddress.setZipcode("34580"); // Sipariş teslimatının yapılacağı posta kodu (Uluslararası posta kodu alanıdır.)
		shippingAddress.setDistrict("Şişli"); // Sipariş teslimatının yapılacağı ilçe (İlçe alanıdır.)
		shippingAddress.setDistrictCode(""); // Sipariş teslimatının yapılacağı ilçe kodu (İlçe kodu alanıdır.)
		shippingAddress.setShippingCompany("XXX"); // Taşıyıcı kargo bilgisi (Taşıyıcı kargo bilgisi alanıdır.)
		payment3DRequest.setShippingaddress(shippingAddress);
		
		/**
		 * Invoice Address
		 * Fature Adresi
		 */
		InvoiceAddress invoceAddress = new InvoiceAddress();
		invoceAddress.setName("Ali Veli"); // Fatura kesilecek kişi veya kurum adı (Maksimum 40 karakterdir. Sadece alfanümerik karakterler, & . ve boşluk karakterini kabul eder.)
		invoceAddress.setAddress("Kuştepe Mahallesi Mecidiyeköy Yolu Cad. No:12 Trump Towers Kule:2 Kat:11 Şişli"); // Fatura adresi (Maksimum 500 karakterdir. Sadece alfanümerik karakterler, &.,/: ve boşluk karakterini kabul eder.)
		invoceAddress.setCountry("Türkiye"); // Fatura ülkesi (Maksimum 20 karakterdir. Sadece alfabetik olabilir.)
		invoceAddress.setCountrycode("TUR"); // Fatura ülkesi (2 veya 3 haneli ISO ülke kodudur. Sadece alfabetik olabilir.)
		invoceAddress.setCity("Istanbul"); // Fatura şehri (Maksimum 20 karakterdir. Sadece alfabetik olabilir.)
		invoceAddress.setCitycode("34"); // Fatura şehri (Şehire ait ulusal veya uluslararası kod alanıdır. Türkiye için plaka kodu kullanılabilir.)
		invoceAddress.setZipcode("34580"); // Fatura zip code (Uluslararası posta kodu alanıdır.)
		invoceAddress.setDistrict("Şişli"); // Sipariş teslimatının yapılacağı ilçe (İlçe alanıdır.)
		invoceAddress.setDistrictCode(""); // Sipariş teslimatının yapılacağı ilçe kodu (İlçe kodu alanıdır.)
		invoceAddress.setShippingCompany("XXX"); // Taşıyıcı kargo bilgisi (Taşıyıcı kargo bilgisi alanıdır.)
		payment3DRequest.setInvoiceaddress(invoceAddress);
		
		/**
		 * Cart
		 * Sepet
		 */
		List<Basketitem> basketList = new ArrayList<>();
		Basketitem firstBasketitem = new Basketitem();
		firstBasketitem.setDescription("Boyama Kalem Seti"); // Ürün ismi (Maksimum 40 karakterdir.)
		firstBasketitem.setProductcode("7cefdf61-38cd-4b35-b5f0-4c98c5805d41"); // Ürün kodu (Maksimum 36 karakterdir.)
		firstBasketitem.setAmount("87,50"); // Ürün fiyatı (Nokta ve virgülden arındırılmış double değerdir.)
		firstBasketitem.setVatratio("18"); // Tutarın KDV içerip içermediğini belirtir (0, 8 veya 18 değerlerini alabilir.)
		firstBasketitem.setCount("1"); // Ürün miktarı (Maksimum 3 haneli nümerik değerdir.)
		firstBasketitem.setUrl("http://www.alivelimarket.com.tr/boyama-kalem-seti"); // Ürün web adresi (Web URL'idir)
		firstBasketitem.setBasketItemType(BasketItemType.PHYSICAL.getCode()); // Ürün tipi (Ürünler için PHYSICAL, Kargo bilgisi için SHIPPING.)
		firstBasketitem.setBasketItemId("basket_1"); // Ürün kodu (Maksimum 40 karakterdir.)
		basketList.add(firstBasketitem);
		
		Basketitem secondBasketitem = new Basketitem();
		secondBasketitem.setDescription("Boyama Kitabı");
		secondBasketitem.setProductcode("7cefdf61-38cd-4b35-b5f0-4c98c5805d41");
		secondBasketitem.setAmount("25,50");
		secondBasketitem.setVatratio("18");
		secondBasketitem.setCount("3");
		secondBasketitem.setUrl("http://www.alivelimarket.com.tr/boyama-kitabi");
		secondBasketitem.setBasketItemType(BasketItemType.PHYSICAL.getCode());
		secondBasketitem.setBasketItemId("basket_2");
		basketList.add(secondBasketitem);
		
		Basketitem thirdBasketitem = new Basketitem();
		thirdBasketitem.setDescription("KargoBedeli");
		thirdBasketitem.setAmount("10,00");
		thirdBasketitem.setVatratio("18");
		thirdBasketitem.setCount("1");
		thirdBasketitem.setBasketItemType(BasketItemType.SHIPPING.getCode());
		thirdBasketitem.setBasketItemId("basket_3");
		basketList.add(thirdBasketitem);

		payment3DRequest.setBasketitems(basketList);

		List<Extra> extraList = new ArrayList<>();
		Extra extra1 = new Extra();
		extra1.setKey("INT_SPRS_KODU");
		extra1.setValue("spr_123456789");
		extraList.add(extra1);

		Extra extra2 = new Extra();
		extra2.setKey("INT_MUSTERI_KODU");
		extra2.setValue("mus_123456789");
		extraList.add(extra2);
		
		payment3DRequest.setExtras(extraList);

		HepsiPaySetting hepsiPaySettings = SampleUtil.generateSampleHepsiPaySetting();
		PaymentService payment3DService = new PaymentService(hepsiPaySettings);
		payment3DService.makePayment3D(payment3DRequest);
	}
	
}
