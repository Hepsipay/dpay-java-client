/*******************************************************************************
 * Copyright (C) 2017 Hepsipay and Contributers
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 ******************************************************************************/
package com.hepsipay.sample;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.hepsipay.client.model.request.card.CardRegisterRequest;
import com.hepsipay.client.model.response.OAuthResponse;
import com.hepsipay.client.model.response.card.CardRegisterResponse;
import com.hepsipay.client.service.OAuthService;
import com.hepsipay.client.service.card.CardService;
import com.hepsipay.client.settings.HepsiPaySetting;

/**
 * 
 * @author Ahmet Faruk Bişkinler,
 * @Support PixelTürk Web Studio, "destek@pixelturk.net"
 *
 */
public class SampleCardRegister {
	private final static Logger logger = LogManager.getRootLogger();

	public static void main(String[] args) {
		CardRegisterRequest registerCardRequest = new CardRegisterRequest();
		registerCardRequest.setFullName("John Doe"); // Kart İsim Soyisim (Maksimum 40 karakterdir. Sadece alfabetik karakterler ve boşluk kabul eder.)
		registerCardRequest.setCardNumber("4508034508034509"); // Kart Numarası (15 veya 16 haneli nümerik değerdir.)
		registerCardRequest.setExpireMonth("10"); // Kart Son Kullanım Tarihi (2 haneli nümerik değerdir.)
		registerCardRequest.setExpireYear("16"); // Kart Son Kullanım Tarihi (2 haneli nümerik değerdir.)
		registerCardRequest.setMerchantUserId("User_2"); // Kullanıcı kodu (Maksimum 40 karakterdir.)
		registerCardRequest.setMerchantUserCardId("Bankxxx_yyy_kartı"); // Kullanıcı kartı bilgisi kodu (Maksimum 40 karakterdir.)

		HepsiPaySetting hepsiPaySettings = SampleUtil.generateSampleHepsiPaySetting();
		CardService cardService = new CardService(hepsiPaySettings);
		OAuthService oauthService = new OAuthService(hepsiPaySettings);
		OAuthResponse login = oauthService.login();
		CardRegisterResponse registerCardResponse = cardService.registerCard(registerCardRequest, login);
		logger.debug(registerCardResponse);
	}
	
	
}
