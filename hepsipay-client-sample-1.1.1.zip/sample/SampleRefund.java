/*******************************************************************************
 * Copyright (C) 2017 Hepsipay and Contributers
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 ******************************************************************************/
package com.hepsipay.sample;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.hepsipay.client.model.request.payment.Refund;
import com.hepsipay.client.model.response.RefundResponse;
import com.hepsipay.client.service.RefundService;
import com.hepsipay.client.settings.HepsiPaySetting;
import com.hepsipay.client.type.Currency;
import com.hepsipay.client.util.HepsiPayUtil;

/**
 * 
 * @author Ahmet Faruk Bişkinler,
 * @Support PixelTürk Web Studio, "destek@pixelturk.net"
 *
 */
public class SampleRefund {
	private final static Logger logger = LogManager.getRootLogger();
	
	public static void main(String[] args) {
		Refund refundRequest = new Refund();
		refundRequest.setTransactionId(HepsiPayUtil.generateRandomTranstionId()); // Ödemeye Ait Tekil Kodu (Maksimum 40 karakterdir)
		refundRequest.setReferenceTransactionId("tx_466943"); // İade Edilecek Ödemeye Ait Tekil Kod (Maksimum 40 karakterdir)
		refundRequest.setAmount("1,00"); // Toplam İade Tutarı
		refundRequest.setCurrency(Currency.TL.getCode()); // Toplam Ödeme Tutar Birimi

		HepsiPaySetting hepsiPaySettings = SampleUtil.generateSampleHepsiPaySetting();
		RefundService refundService = new RefundService(hepsiPaySettings);
		RefundResponse refundResponse = refundService.makeRefund(refundRequest);
		
		logger.debug(refundResponse);
	}
	
}
